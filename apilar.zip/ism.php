<?php
header('Content-Type: application/json; charset=utf-8');
$ism = $_GET['ism'];
$sayt =file_get_contents("https://ismlar.com/name/".$ism);
$ism =explode('<h2 class="font-bold text-xl mb-4">', $sayt);
$ism =explode('</h2>',$ism[1]);
$ism = $ism[0];
$ism = trim($ism);

$mano =explode('<div class="space-y-4">', $sayt);
$mano =explode('</div>',$mano[1]);
$mano = $mano[0];
$mano= str_replace(["<p>"],[""],$mano);
$mano = str_replace(["</p>"],[""],$mano);
$mano= str_replace(["\n"],[""],$mano);
$mano = trim($mano);


$shakl =explode('<span class="">Shakllari:</span>', $sayt);
$shakl =explode('</span>',$shakl[1]);
$shakl = $shakl[0];
$shakl= str_replace(["<span class=\"\">"],[""],$shakl);
$shakl = str_replace(["\n"],[""],$shakl);
$shakl = str_replace(["                                                                                                                   "],[""],$shakl);
$shakl = str_replace(["                    "],[""],$shakl);
$shakl = trim($shakl);

$tur =explode('<div class="capitalize">', $sayt);
$tur =explode('</div>',$tur[1]);
$tur = $tur[0];
$tur = str_replace(["\n"],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Arabcha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Boshqalar" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/o%E2%80%98zbekcha,%20fors-tojikcha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/o%E2%80%98zbekcha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Fors-tojikch" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Yahudiycha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Mo%E2%80%98g%E2%80%98ulcha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Qozoqcha" class="">'],[""],$tur);
$tur = str_replace(['<a href="https://ismlar.com/category/Turkiy" class="">'],[""],$tur);
$tur = str_replace(["\n"],[""],$tur);
$tur = str_replace(["                                                                                                                "],[""],$tur);
$tur = str_replace(["</a>"],[""],$tur);
$tur = trim($tur);

$a = array(
'ism'=>"$ism",
'mano'=>"$mano",
'shakllari'=>"$shakl",
'tur'=>"$tur");

echo json_encode($a);