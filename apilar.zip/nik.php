<?php
  ob_start();
  set_time_limit(0);
 define('API_KEY','5023911804:AAFLjLzGpIExMvTT6Lbot-QiNSjrbOmUmDg');
  $admin = ["621617473","848219657"];
  
  define('LOGIN','yozmelar_tiktok');
  define('PAROL','Coder@96');
  define('DBNAME','yozmelar_tiktok');
 
  
  
  function bot($method,$datas=[]){
      $url = "https://api.telegram.org/bot".API_KEY."/".$method;
      $ch = curl_init();
      curl_setopt($ch,CURLOPT_URL,$url);
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
      $res = curl_exec($ch);
      if(curl_error($ch)){
          var_dump(curl_error($ch));
      }else{
          return json_decode($res);
      }
  }
  
  function  top($fid){
  global $conn;
  $text ="";
$topop = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM nik WHERE fid ='$fid'"));
$_top = $topop['sevimli'];
$topip = json_decode($_top);
$array = $topip->niklar;
$vals = array_count_values($array);
$n = 1;
foreach ($array as $user) {
echo "$n - $user\n";
$text .="$n - $user\n";
$n++;
}
return $text;
}
  
 $conn = mysqli_connect("localhost", LOGIN, PAROL, DBNAME);
$conn->query("SET NAMES 'utf8mb4'");
$conn->query("SET CHARACTER SET utf8mb4");
$conn->query("SET SESSION collation_connection = 'utf8mb4_general_ci'");
if(mysqli_connect_errno()){
    echo "xato aniqlandi: <br />" .mysqli_connect_error();
}


  
  $query3 = mysqli_query($conn,"create table nik(
  id int(20) auto_increment primary key,
  name varchar(40) CHARACTER SET utf8mb4,
  fid varchar(20) CHARACTER SET utf8mb4,
  sana varchar(20) CHARACTER SET utf8mb4,
  step varchar(10) CHARACTER SET utf8mb4,
  nik mediumtext CHARACTER SET utf8mb4,
  sevimli mediumtext CHARACTER SET utf8mb4
  )");
  if($query3){
  echo "Jadvali yaratildi</br>";
  }else{
  echo "Xato $conn->error";
  }
  
  
  
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$fid = $update->message->from->id;
$chat_id = $update->message->chat->id;
$text = $update->message->text;
$data = $update->callback_query->data;
$cqid = $update->callback_query->id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$fid2 = $update->callback_query->message->chat->id;
$ch_user2 = $update->callback_query->message->chat->username;
$mesid = $update->callback_query->message->message_id;
$fadmin2 = $update->callback_query->from->id;
$name2 = $update->callback_query->from->first_name;
$username2 = $update->callback_query->from->username;
$reply = $message->reply_to_message->text;
$name = str_replace(["[","]","(",")","*","_","`"],["","","","","","",""],$message->from->first_name);
$sana = date('H:i  d.m.Y');
$username = $message->from->username;
$type = $update->message->chat->type;
$fromid = $update->callback_query->from->id;
$mid = $update->message->message_id;

date_default_timezone_set("Asia/Tashkent");
  $soat = date('d.m.Y');

    if(!empty($update->message->chat->type) and ($update->message->chat->type == "private")){
  $query = mysqli_query($conn,"SELECT * FROM `nik` WHERE `fid`='".$fid."'");
  $tek = mysqli_fetch_assoc($query);
  if($tek){
  }else{
  mysqli_query($conn,"INSERT INTO nik (`name`,`fid`,`sana`,`step`,`nik`,`sevimli`) VALUES  ('$name','$fid','$soat','','','')");
  }
  }
  
  //Keyboard
  $lan = json_encode([
  'inline_keyboard'=>[
  [["text"=>"🇺🇿O`zbek tili","callback_data"=>"uz"],["text"=>"🇷🇺Русский язык","callback_data"=>"ru"]],
  [["text"=>"English 🇺🇸","callback_data"=>"en"]],
  ]
  ]);
  
  if((mb_stripos($text,"/start")!==false)){
  bot('sendmessage',[
          'chat_id'=>$chat_id,
          'text'=>"<b>🇬🇧Choose the bot language:
  🇷🇺Выберите язык бота: 
  🇺🇿Bot tilini tanlang:</b>",
          'parse_mode'=>'html',
          'reply_markup'=>$lan,
  ]);
  }
  
if(file_get_contents("son.txt")){
}else{   
 file_put_contents("son.txt","16");
}
$user = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM nik WHERE fid = '$fid' LIMIT 1"));


if(mb_stripos($text,"/test")!==false){
 // if(joinchat($fid)=="true"){
  bot('sendMessage',[
  'chat_id'=>$fid,
  'text'=>"Nik uchun soz yuboring",
  'parse_mode'=>'html',
  ]);
  mysqli_query($conn,"UPDATE `nik` SET `step` = 'nik' WHERE fid = '$fid' ");
  }
  
  
$tutalpages = file_get_contents("son.txt");
if($user['step'] =="nik"){
$ism = str_replace(" ","%20",$text);
mysqli_query($conn,"UPDATE `nik` SET `nik` = '".$ism."' WHERE fid = '$fid' ");
$uzpage = 1; 
$nik = file_get_contents ("https://yozmelar.tk/perser/nik/1.php?text=$ism&son=$uzpage");
if($uzpage <= 1){ 
  $pruv = "⚫️";  
  $pru="i"; 
}else { 
$pruv="1x⬅️"; 
$pruvc= $uzpage - 1; 
$pru="pruv$pruv"; 
} 
if($uzpage >= $tutalpages){ 
$niht="⚫️"; 
$nih="i"; 
} else { 
$niht="1x➡️"; 
$nihtc = $uzpage + 1;  
$nih = "niht$nihtc"; 
} 
bot("sendmessage",[
'chat_id'=>$chat_id,  
"text"=>"$uzpage Tayyor: $nik

◼️ Nusxalash: <code>$nik</code>  👈 (b ̶o ̶s ̶i ̶n ̶g)
◻️ Orginali: $text",
"parse_mode"=>"html",
 	'reply_markup'=>json_encode([
"inline_keyboard"=>[
[['text'=>"$pruv",'callback_data'=>"$pru"],["text"=>"$uzpage/$tutalpages","callback_data"=>"null"],['text'=>"$niht",'callback_data'=>"$nih"]], 
[["callback_data"=>"bosh$nik","text"=>"🟡Tanlash"]]
]
       ])  
]); 
}




if(strstr($data,"niht")) {
$dataa=str_replace("niht","",$data);
         $uzpage =  $dataa;
 $result7 = mysqli_query($conn,"SELECT * FROM nik WHERE fid = '$fid2'");
$row7 = mysqli_fetch_assoc($result7);
$ism = $row7['nik'];     
$nik = file_get_contents("https://yozmelar.tk/perser/nik/1.php?text=$ism&son=$uzpage");
if($uzpage <= 1){
  $pruv = "⚫️"; 
  $pru="o";
}else {
$pruv="1x⬅️";
$pruvc= $uzpage - 1;
$pru="pruv$pruvc";
}
if($uzpage >= $tutalpages){
$niht="⚫️";
$nih="o";
} else {
$niht="1x➡️";
$nihtc = $uzpage + 1; 
$nih="niht$nihtc";
}
bot("deleteMessage",[
'chat_id'=>$fid2,
'message_id'=>$mesid,
]);
bot("sendmessage",[
'chat_id'=>$fid2,  
"text"=>"$uzpage Tayyor: $nik

◼️ Nusxalash: <code>$nik</code>  👈 (b ̶o ̶s ̶i ̶n ̶g)
◻️ Orginali: $text",
"parse_mode"=>"html",
 	'reply_markup'=>json_encode([
"inline_keyboard"=>[
[['text'=>"$pruv",'callback_data'=>"$pru"],["text"=>"$uzpage/$tutalpages","callback_data"=>"null"],['text'=>"$niht",'callback_data'=>"$nih"]], 
[["callback_data"=>"bosh$nik","text"=>"🟡Tanlash"]]
]
       ])  
]); 
}elseif(strstr($data,"pruv")){
$dataa=str_replace("pruv","",$data);
$uzpage = $dataa;
 $result7 = mysqli_query($conn,"SELECT * FROM nik WHERE fid = '$fid2'");
$row7 = mysqli_fetch_assoc($result7);
$ism = $row7['nik'];     
$nik = file_get_contents("https://yozmelar.tk/perser/nik/1.php?text=$ism&son=$uzpage");
if($uzpage <= 1){
  $pruv = "⚫️"; 
  $pru="mm";
}else { 
$pruv="1x⬅️";
$pruvc= $uzpage - 1;
$pru="pruv$pruvc";

}
if($uzpage >= $tutalpages){
$niht="⚫️";
$nih="mm";
} else {
$niht="1x➡️";
$nihtc = $uzpage + 1; 
$nih="niht$nihtc";
}
bot("deleteMessage",[
'chat_id'=>$fid2,
'message_id'=>$mesid,
]);
bot("sendmessage",[
'chat_id'=>$fid2,  
"text"=>"$uzpage Tayyor: $nik

◼️ Nusxalash: <code>$nik</code>  👈 (b ̶o ̶s ̶i ̶n ̶g)
◻️ Orginali: $text",
"parse_mode"=>"html",
 	'reply_markup'=>json_encode([
"inline_keyboard"=>[
[['text'=>"$pruv",'callback_data'=>"$pru"],["text"=>"$uzpage/$tutalpages","callback_data"=>"null"],['text'=>"$niht",'callback_data'=>"$nih"]], 
[["callback_data"=>"bosh$nik","text"=>"🟡Tanlash"]]
]
       ])  
]); 
}

if(strstr($data,"bosh")){
$dataa=str_replace("bosh","",$data); 
$uzpage = $dataa;
$toop = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `nik` WHERE `fid` ='$fid2'"));
$topi = json_decode($toop["sevimli"], true);
    $topi['niklar'][] = $uzpage;   
$p = json_encode($topi,JSON_UNESCAPED_UNICODE);
$p = mysqli_real_escape_string($conn,$p);
mysqli_query($conn,"UPDATE `nik` SET `sevimli`='".$p."' WHERE fid='$fid2'");
bot("answerCallbackQuery",[
"callback_query_id"=>$cqid,
"text"=>"❤Sevimlilarga saqlandi.",
"show_alert"=>true,
]);
}




$reyting = top($fid);
if($text=="❤Sevimlilar"){
bot ('sendmessage', [
'chat_id'=> $fid,
'text'=>" 😑 $reyting", 
]);
}





if(strstr($text,"/del_")){
$dataa=explode("_",$text);  
$uzpage = $dataa[1];
$fetch = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `nik` WHERE `fid` ='$fid'"));
$nik = json_decode($fetch['sevimli'],true);
unset($nik['niklar'],[1]);
$arr_new = json_encode($nik,JSON_UNESCAPED_UNICODE );
$arr_new = mysqli_real_escape_string($conn,$arr_new);
mysqli_query($conn,"UPDATE `nik` SET `sevimli`='".$arr_new."' WHERE fid='$fid'");
bot("sendmessage",[
"chat_id"=>$fid,
"text"=>"🙄$arr_new
$uzpage ochirildi



⏱️$nik",
]);
}

