function VideoBox_ShowControlDetail($index) {
  $_VIDEOs_DATAs[$index].Detail.show();
  $_VIDEOs_DATAs[$index].BorderRight.show();
  $_VIDEOs_DATAs[$index].BorderLeft.show();
  $_VIDEOs_DATAs[$index].Control.show();
  $_VIDEOs_DATAs[$index].VideoBox.css('cursor', 'default');
}
function VideoBox_HideControlDetail($index) {
  $_VIDEOs_DATAs[$index].Detail.fadeOut();
  $_VIDEOs_DATAs[$index].BorderRight.fadeOut();
  $_VIDEOs_DATAs[$index].BorderLeft.fadeOut();
  $_VIDEOs_DATAs[$index].Control.fadeOut();
  $_VIDEOs_DATAs[$index].VideoBox.css('cursor', 'none');
}
function VideoBox_HideControlDetailWithTimer($index) {
  clearTimeout($_VIDEOs_DATAs[$index].Timeout_MouseNotMove);
  // if playing
  if(!$_VIDEOs_DATAs[$index].Video[0].paused) {
    $_VIDEOs_DATAs[$index].Timeout_MouseNotMove = setTimeout( function() { 
      VideoBox_HideControlDetail($index); 
    }, 3000);
  }
}
//-----------------------------------
function VideoBox_OnMouseEnter($index) {
  clearTimeout($_VIDEOs_DATAs[$index].Timeout_MouseNotMove);

  VideoBox_ShowControlDetail($index);
}
function VideoBox_OnMouseMove($index) {
  VideoBox_HideControlDetailWithTimer($index);

  VideoBox_ShowControlDetail($index);
}
function VideoBox_OnMouseLeave($index) {
  clearTimeout($_VIDEOs_DATAs[$index].Timeout_MouseNotMove);

  if( $_VIDEOs_DATAs[$index].Video[0].paused ) {
    VideoBox_ShowControlDetail($index);
  } // paused
  else {
    VideoBox_HideControlDetail($index);
  } // palying
}


// Video Progress Update by Playing
// Fires when the current playback position has changed
function Video_VideoOnTimeUpdate($index) {
  // when dont use poster and use a code like '#t=2.2' after video src
  // video currentTime will change
  if($_VIDEOs_DATAs[$index].FirstTimePlayVideo == true) return;



  $percentComplete = (($_VIDEOs_DATAs[$index].Video[0].currentTime / $_VIDEOs_DATAs[$index].Video[0].duration)*100) + '%';
  $_VIDEOs_DATAs[$index].ProgressValue.width($percentComplete);



  // show time [currentTime / duration]
  $buffM = parseInt($_VIDEOs_DATAs[$index].Video[0].currentTime / 60);
  $buffS = parseInt($_VIDEOs_DATAs[$index].Video[0].currentTime % 60);
  if($buffM.toString().length == 1) $buffM = "0" + $buffM;
  if($buffS.toString().length == 1) $buffS = "0" + $buffS;
  $_VIDEOs_DATAs[$index].Current.text($buffM + ":" + $buffS);
  //---
  $buffM = parseInt($_VIDEOs_DATAs[$index].Video[0].duration / 60);
  $buffS = parseInt($_VIDEOs_DATAs[$index].Video[0].duration % 60);
  if($buffM.toString().length == 1) $buffM = "0" + $buffM;
  if($buffS.toString().length == 1) $buffS = "0" + $buffS;
  $_VIDEOs_DATAs[$index].Duration.text($buffM + ":" + $buffS);
}
// Video Progress Update by User [ just Click ]
function Video_ProgressOnClick(event, $index) {
  if(!$_VIDEOs_DATAs[$index].Video[0].ended) {
    $offset = $_VIDEOs_DATAs[$index].Progress.offset();
    $left = (event.pageX - $offset.left); 
    $totalWidth = $_VIDEOs_DATAs[$index].Progress.width();
    $percentage = ( $left / $totalWidth );
    $vidTime = $_VIDEOs_DATAs[$index].Video[0].duration * $percentage;
    $_VIDEOs_DATAs[$index].Video[0].currentTime = $vidTime;
  }
}
// Video Progress Update by User [ Click + Moving ]
function Video_ProgressOnMouseDown($index) {
  $_VIDEOs_DATAs[$index].ChangeProgressClicking = true;
}


// Fires when the browser is downloading the audio/video
function Video_VideoOnProgress($index) {
  $_VideoBufferedBackground = "linear-gradient(to right";

  for($index2 = 0; $index2 < $_VIDEOs_DATAs[$index].Video[0].buffered.length; $index2++) {
    $CurrentStartPercent = parseInt(($_VIDEOs_DATAs[$index].Video[0].buffered.start($index2) / $_VIDEOs_DATAs[$index].Video[0].duration)*100);
    $CurrentEndPercent = parseInt(($_VIDEOs_DATAs[$index].Video[0].buffered.end($index2) / $_VIDEOs_DATAs[$index].Video[0].duration)*100);

    if( $index2 == 0 ) {
      $_VideoBufferedBackground += 
        ", #2c3e50 " + $CurrentStartPercent + "%, #2c3e50 " + $CurrentEndPercent + "%";
    }
    else {
      $PreviousStartPercent = parseInt(($_VIDEOs_DATAs[$index].Video[0].buffered.start($index2-1) / $_VIDEOs_DATAs[$index].Video[0].duration)*100);
      $PreviousEndPercent = parseInt(($_VIDEOs_DATAs[$index].Video[0].buffered.end($index2-1) / $_VIDEOs_DATAs[$index].Video[0].duration)*100);

      $_VideoBufferedBackground += 
        ", transparent " + $PreviousEndPercent + "%, transparent " + $CurrentStartPercent + "%" +
        ", #2c3e50 " + $CurrentStartPercent + "%, #2c3e50 " + $CurrentEndPercent + "%";
    }
  };

  $_VideoBufferedBackground += ", transparent " + $CurrentEndPercent + "%, transparent 100%)";

  $_VIDEOs_DATAs[$index].ProgressDownload.css("background", $_VideoBufferedBackground);
}

 
// Play / Pause Keys
function Video_PlayPause($index) {
  if($_VIDEOs_DATAs[$index].Video[0].paused) {
    if($_VIDEOs_DATAs[$index].FirstTimePlayVideo == true) {
      $_VIDEOs_DATAs[$index].FirstTimePlayVideo = false;
      $_VIDEOs_DATAs[$index].Video[0].currentTime = 0;
    }

    $_VIDEOs_DATAs[$index].Video[0].play();
    $_VIDEOs_DATAs[$index].Play.hide();
    $_VIDEOs_DATAs[$index].Pause.show();
    
    VideoBox_HideControlDetailWithTimer($index);
  }
  else {
    $_VIDEOs_DATAs[$index].Video[0].pause();
    $_VIDEOs_DATAs[$index].Play.show();
    $_VIDEOs_DATAs[$index].Pause.hide();

    clearTimeout($_VIDEOs_DATAs[$index].Timeout_MouseNotMove);
    VideoBox_ShowControlDetail($index);
  }
}
// videoEnd Event
function Video_VideoOnEnded($index) {
  clearTimeout($_VIDEOs_DATAs[$index].Timeout_MouseNotMove);
  VideoBox_ShowControlDetail($index);
  
  $_VIDEOs_DATAs[$index].Play.show();
  $_VIDEOs_DATAs[$index].Pause.hide();
  $_VIDEOs_DATAs[$index].Video[0].currentTime = 0;
}


// VolumeIcon OnClick [Show/Hide VolumeBox]
function Video_VolumeIconOnClick($index) {
  if( $_VIDEOs_DATAs[$index].VolumeBox.css("display") == "none" ) {
    $_VIDEOs_DATAs[$index].VolumeBox.css("display", "flex");
  }
  else {
    $_VIDEOs_DATAs[$index].VolumeBox.css("display", "none");
  }
}
// VolumeBoxIcon OnClick [Mute/unMute Volume]
function Video_VolumeBoxIconOnClick($index) {
  if($_VIDEOs_DATAs[$index].Video[0].muted == true) { 
    $_VIDEOs_DATAs[$index].Video[0].muted = false; 
  }
  else { 
    $_VIDEOs_DATAs[$index].Video[0].muted = true; 
  }
}
// Volume Value Update by User [ just Click ]
function Video_VolumeProcessOnClick(event, $index) {
  $_VIDEOs_DATAs[$index].Video[0].muted = false;

  $offset = $_VIDEOs_DATAs[$index].VolumeProcess.offset();
  $left = (event.pageX - $offset.left);
  $totalWidth = $_VIDEOs_DATAs[$index].VolumeProcess.width();
  $percentage = ( $left / $totalWidth );
  $_VIDEOs_DATAs[$index].Video[0].volume = parseFloat($percentage,2);
}
// Volume Value Update by User [ Click + Moving ]
function Video_VolumeProcessOnMouseDown($index) { 
  $_VIDEOs_DATAs[$index].ChangeVolumeClicking = true;
}
// onVolumeChange Event
function Video_VideoOnVolumeChange($index) {
  $volumeValue = parseInt($_VIDEOs_DATAs[$index].Video[0].volume * 100);

  if($_VIDEOs_DATAs[$index].Video[0].muted == true) {
    $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("display", "none");
    $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("display", "none");
    $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("display", "none");
    $_VIDEOs_DATAs[$index].VolumeAllIconsPath5.css("display", "flex");
  }
  else {
    if($volumeValue == 0) {
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("display", "none");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("display", "none");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("display", "none");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath5.css("display", "flex");
    }
    else if($volumeValue > 0 && $volumeValue < 33) {
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath5.css("display", "none");
      //---
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("fill", "white");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("fill", "#7f8fa6"); // white
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("fill", "#7f8fa6"); // white
    }
    else if($volumeValue >= 33 && $volumeValue < 66) {
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath5.css("display", "none");
      //---
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("fill", "white");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("fill", "white");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("fill", "#7f8fa6"); // white
    }
    else if($volumeValue >= 66) {
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("display", "flex");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath5.css("display", "none");
      //---
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath2.css("fill", "white");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath3.css("fill", "white");
      $_VIDEOs_DATAs[$index].VolumeAllIconsPath4.css("fill", "white");
    }
  }

  // set volume process
  $_VIDEOs_DATAs[$index].VolumeProcessValue.width($volumeValue + "%");

  // set volume text
  $_VIDEOs_DATAs[$index].VolumeText.text($volumeValue + "%");

  // auto hide volumeBox
  clearTimeout($_VIDEOs_DATAs[$index].TimeOut_VolumeBoxShowing);
  $_VIDEOs_DATAs[$index].TimeOut_VolumeBoxShowing = setTimeout(function() { 
    $_VIDEOs_DATAs[$index].VolumeBox.css("display", "none"); 
  }, 3000);
}


// Download Button onClick
function Video_Download($index) {
  $_VIDEOs_DATAs[$index].Download.attr("href", $_VIDEOs_DATAs[$index].Video[0].currentSrc);
}


// Fullscreen/ExitFullscreen Keys
function Video_FullScreen_ExitFullScreen($index) {
  if (document.fullscreenElement != null) {
    document.exitFullscreen();
    //---
    $_VIDEOs_DATAs[$index].FullScreen.show();
    $_VIDEOs_DATAs[$index].ExitFullScreen.hide();
  } 
  else {
    $_VIDEOs_DATAs[$index].VideoBox[0].requestFullscreen(); 
    //---
    $_VIDEOs_DATAs[$index].FullScreen.hide();
    $_VIDEOs_DATAs[$index].ExitFullScreen.show();
  }
}


// 	Fires when the video stops because it needs to buffer the next frame
function Video_VideoOnWaiting($index) {
  $_VIDEOs_DATAs[$index].Loader.css('display', 'flex');
}
// Fires when the browser can start playing the specified audio/video (when it has buffered enough to begin).
function Video_VideoOnCanPlay($index) {
  $_VIDEOs_DATAs[$index].Loader.css('display', 'none');  
}



// Control [Volume] with : arrow[up,down] / middleButtonMouse[up,down]
// Control [CurrentTime] with : arrow[left,righht]
// Control [Play/Pause] with : space
$(document).on('keydown', function(event) { 
  $.each( $_VIDEOs_DATAs, function( $index, $value ) {
    if( $_VIDEOs_DATAs[$index].VideoBox.is(":hover") ) {
      switch (event.keyCode) {
        case 38: // up [ increase volume ]
          event.preventDefault();
          //---
          $buff = $_VIDEOs_DATAs[$index].Video[0].volume;
          $buff+=0.02;
          if($buff > 1.0) $buff = 1.0;
          $_VIDEOs_DATAs[$index].Video[0].volume = $buff;
          //---
          $_VIDEOs_DATAs[$index].VolumeBox.css("display", "flex");
          //---
          break;
        case 40: // down [ decrease volume ]
          event.preventDefault();
          //---
          $buff = $_VIDEOs_DATAs[$index].Video[0].volume;
          $buff-=0.02;
          if($buff < 0.0) $buff = 0.0;
          $_VIDEOs_DATAs[$index].Video[0].volume = $buff;
          //---
          $_VIDEOs_DATAs[$index].VolumeBox.css("display", "flex");
          //---
          break;

        case 37: // left [ jumpBack ]
          event.preventDefault();
          //---
          $buff = $_VIDEOs_DATAs[$index].Video[0].currentTime;
          $buff-=1;
          if($buff < 0) $buff = 0;
          $_VIDEOs_DATAs[$index].Video[0].currentTime = $buff;
          //---
          break;
        case 39: // right [ JumpForward ]
          event.preventDefault();
          //---
          $buff = $_VIDEOs_DATAs[$index].Video[0].currentTime;
          $buff+=1;
          if($buff > $_VIDEOs_DATAs[$index].Video[0].duration) $buff = $_VIDEOs_DATAs[$index].Video[0].duration;
          $_VIDEOs_DATAs[$index].Video[0].currentTime = $buff;
          //---
          break;

        case 32: // space [ Play/Pause ]
          event.preventDefault();
          //---
          Video_PlayPause($index);
          //---
          break;
      }
    }
  });
}); 

// for change video currentTime and volume value
$(document).on('mouseup touchend', function(event) {
  $.each( $_VIDEOs_DATAs, function( $index, $value ) {
    $_VIDEOs_DATAs[$index].ChangeProgressClicking = false; 
    $_VIDEOs_DATAs[$index].ChangeVolumeClicking = false; 
  });
});
$(document).on('mousemove', function(event) {
  $.each( $_VIDEOs_DATAs, function( $index, $value ) {
    if($_VIDEOs_DATAs[$index].ChangeProgressClicking == true) {
      if(!$_VIDEOs_DATAs[$index].Video[0].ended) {
        $offset = $_VIDEOs_DATAs[$index].Progress.offset();
        $left = (event.pageX - $offset.left);
        $totalWidth = $_VIDEOs_DATAs[$index].Progress.width();
        $percentage = ( $left / $totalWidth );
        $vidTime = $_VIDEOs_DATAs[$index].Video[0].duration * $percentage;
        $_VIDEOs_DATAs[$index].Video[0].currentTime = $vidTime;
      }
    }
    else if($_VIDEOs_DATAs[$index].ChangeVolumeClicking == true) {
      $_VIDEOs_DATAs[$index].Video[0].muted = false;

      $offset = $_VIDEOs_DATAs[$index].VolumeProcess.offset();
      $video_xPos = event.pageX;
      $left = ($video_xPos - $offset.left);
      $totalWidth = $_VIDEOs_DATAs[$index].VolumeProcess.width();
      $percentage = ( $left / $totalWidth );
      if($percentage < 0.0) $percentage = 0.0;
      if($percentage > 1.0) $percentage = 1.0;
      $_VIDEOs_DATAs[$index].Video[0].volume = $percentage;
    }
  });
});
$(document).on('touchmove', function(event) {
  $.each( $_VIDEOs_DATAs, function( $index, $value ) {
    if($_VIDEOs_DATAs[$index].ChangeProgressClicking == true) {
      if(!$_VIDEOs_DATAs[$index].Video[0].ended) {
        $offset = $_VIDEOs_DATAs[$index].Progress.offset();
        $video_xPos = event.originalEvent.touches[0].pageX;
        $left = ($video_xPos - $offset.left);
        $totalWidth = $_VIDEOs_DATAs[$index].Progress.width();
        $percentage = ( $left / $totalWidth );
        $vidTime = $_VIDEOs_DATAs[$index].Video[0].duration * $percentage;
        $_VIDEOs_DATAs[$index].Video[0].currentTime = $vidTime;
      }
    }
    else if($_VIDEOs_DATAs[$index].ChangeVolumeClicking == true) {
      $_VIDEOs_DATAs[$index].Video[0].muted = false;

      $offset = $_VIDEOs_DATAs[$index].VolumeProcess.offset();
      $video_xPos = event.originalEvent.touches[0].pageX;
      $left = ($video_xPos - $offset.left);
      $totalWidth = $_VIDEOs_DATAs[$index].VolumeProcess.width();
      $percentage = ( $left / $totalWidth );
      if($percentage < 0.0) $percentage = 0.0;
      if($percentage > 1.0) $percentage = 1.0;
      $_VIDEOs_DATAs[$index].Video[0].volume = $percentage;
    }
  });
});

// Fullscreen Event
$(document).on('fullscreenchange', function(e) {
  $.each( $_VIDEOs_DATAs, function( $index, $value ) {
    if (document.fullscreenElement != null) {
      $_VIDEOs_DATAs[$index].FullScreen.hide();
      $_VIDEOs_DATAs[$index].ExitFullScreen.show();
    } 
    else {
      $_VIDEOs_DATAs[$index].FullScreen.show();
      $_VIDEOs_DATAs[$index].ExitFullScreen.hide();
    }
  });
});

// document ready
$_VIDEOs_DATAs = [];
$(document).ready(function() {
  // onkeydown and other not work if page dont have focus
  //$(window).focus();

  // do this works for all videos :
  // 1) set id for this videoBox
  // 2) store all variable needed
  // 3) add tags event
  // 4) init volume
  $AllVideoBox = $(".videoBox");
  $.each( $AllVideoBox, function( $index, $value ) {
    // add id to this VideoBox
    $id = 'video' + $index;
    $value.id = $id;



    // store all variable needed
    $_VIDEOs_DATA = { 
      "VideoBox": $("#" + $id),
      "Video": $("#" + $id + " video"),
      "Loader": $("#" + $id + " .videoBox-Loader"),
      "Detail": $("#" + $id + " .videoBox-detail"),
      "BorderRight": $("#" + $id + " .videoBox-borderRight"),
      "BorderLeft": $("#" + $id + " .videoBox-borderLeft"),
      "Control": $("#" + $id + " .videoBox-control"),
      //---
      "Play": $("#" + $id + " .videoBox-playPause svg:nth-child(1)"),
      "Pause": $("#" + $id + " .videoBox-playPause svg:nth-child(2)"),
      //---
      "VolumeIcon": $("#" + $id +  " .videoBox-volumeIcon"),
      //---
      "VolumeBox": $("#" + $id + " .videoBox-volumeBox"),
      "VolumeBoxIcon": $("#" + $id + " .videoBox-volumeBox .videoBox-volumeIcon"),
      "VolumeProcess": $("#" + $id + " .videoBox-volumeBox .videoBox-volumeProcess"),
      "VolumeProcessValue": $("#" + $id + " .videoBox-volumeBox .videoBox-volumeProcess div"),
      "VolumeText": $("#" + $id + " .videoBox-volumeBox .videoBox-volumeText"),
      //---
      "VolumeAllIconsPath2": $("#" + $id +  " .videoBox-volumeIcon svg path:nth-child(2)"),
      "VolumeAllIconsPath3": $("#" + $id +  " .videoBox-volumeIcon svg path:nth-child(3)"),
      "VolumeAllIconsPath4": $("#" + $id +  " .videoBox-volumeIcon svg path:nth-child(4)"),
      "VolumeAllIconsPath5": $("#" + $id +  " .videoBox-volumeIcon svg path:nth-child(5)"),
      //---
      "Current": $("#" + $id + " .videoBox-time span:nth-child(1)"),
      "Duration": $("#" + $id + " .videoBox-time span:nth-child(3)"),
      //---
      "Progress": $("#" + $id + " .videoBox-videoProgress"),
      "ProgressDownload": $("#" + $id + " .videoBox-videoProgress div:nth-child(1)"),
      "ProgressValue": $("#" + $id + " .videoBox-videoProgress div:nth-child(2)"),
      //---
      "Download": $("#" + $id + " .videoBox-download"),
      //---
      "FullScreen": $("#" + $id + " .videoBox-fullScreen svg:nth-child(1)"),
      "ExitFullScreen": $("#" + $id + " .videoBox-fullScreen svg:nth-child(2)"),
      //---
      "Timeout_MouseNotMove": "",
      "ChangeProgressClicking": false,
      "ChangeVolumeClicking": false,
      "FirstTimePlayVideo": true,
      "TimeOut_VolumeBoxShowing": "",
    };
    $_VIDEOs_DATAs.push($_VIDEOs_DATA);



    // VideoBox Events
    $_VIDEOs_DATAs[$index].VideoBox.attr("onmouseenter", "VideoBox_OnMouseEnter('" + $index  + "')");
    $_VIDEOs_DATAs[$index].VideoBox.attr("onmousemove", "VideoBox_OnMouseMove('" + $index  + "')");
    $_VIDEOs_DATAs[$index].VideoBox.attr("onmouseleave", "VideoBox_OnMouseLeave('" + $index  + "')");

    // Video Events
    $_VIDEOs_DATAs[$index].Video.attr("onclick", "Video_PlayPause('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("ontimeupdate", "Video_VideoOnTimeUpdate('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("onended", "Video_VideoOnEnded('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("onvolumechange", "Video_VideoOnVolumeChange('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("onprogress", "Video_VideoOnProgress('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("onwaiting", "Video_VideoOnWaiting('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Video.attr("oncanplay", "Video_VideoOnCanPlay('" + $index  + "')");

    // Play/Pause Buttons onclick
    $_VIDEOs_DATAs[$index].Play.attr("onclick", "Video_PlayPause('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Pause.attr("onclick", "Video_PlayPause('" + $index  + "')");

    // VolumeIcon onclick
    $_VIDEOs_DATAs[$index].VolumeIcon.attr("onclick", "Video_VolumeIconOnClick('" + $index  + "')");
    // VolumeBoxIcon onclick
    $_VIDEOs_DATAs[$index].VolumeBoxIcon.attr("onclick", "Video_VolumeBoxIconOnClick('" + $index  + "')");
    // VolumeProcess [onclick, onmousedown]
    $_VIDEOs_DATAs[$index].VolumeProcess.attr("onclick", "Video_VolumeProcessOnClick(event,'" + $index  + "')");
    $_VIDEOs_DATAs[$index].VolumeProcess.attr("onmousedown", "Video_VolumeProcessOnMouseDown('" + $index  + "')");
    $_VIDEOs_DATAs[$index].VolumeProcess.attr("ontouchstart", "Video_VolumeProcessOnMouseDown('" + $index  + "')");

    // Progress [onclick, onmousedown]
    $_VIDEOs_DATAs[$index].Progress.attr("onclick", "Video_ProgressOnClick(event,'" + $index  + "')");
    $_VIDEOs_DATAs[$index].Progress.attr("onmousedown", "Video_ProgressOnMouseDown('" + $index  + "')");
    $_VIDEOs_DATAs[$index].Progress.attr("ontouchstart", "Video_ProgressOnMouseDown('" + $index  + "')");

    // Download onclick
    $_VIDEOs_DATAs[$index].Download.attr("onclick", "Video_Download('" + $index  + "')");

    // Fullscreen/ExitFullscreen Buttons onclick
    $_VIDEOs_DATAs[$index].FullScreen.attr("onclick", "Video_FullScreen_ExitFullScreen('" + $index  + "')");
    $_VIDEOs_DATAs[$index].ExitFullScreen.attr("onclick", "Video_FullScreen_ExitFullScreen('" + $index  + "')");



    // init volume
    $_VIDEOs_DATAs[$index].Video[0].volume = 0.5;



    // if poster attribute not set for this video
    if( $_VIDEOs_DATAs[$index].Video[0].poster == "" ) {
      $_VIDEOs_DATAs[$index].Video[0].poster = "https://dmf313.ir/wp-content/themes/myTheme/Images/videoDefaultPoster.png";
    }
  });
});