<?php
$LANG["uz"]['name_language'] = "🇺🇿O'zbek tili";
$LANG["uz"]['Choose_language'] = "Iltimos tilni tanlang";
$LANG["uz"]['changed_language'] = "🇺🇿O'zbek tili saqlandi

📁 Ushbu Ushbu bot orqali siz Chiroyli nik tayyorlashingiz mumkin";
$LANG["uz"]['menu1'] = "Pechatsiz video 🎞";
$LANG["uz"]['menu2'] = "Pechatli video📇";
$LANG["uz"]['menu3'] = "Musiqa🎶";
$LANG["uz"]['Back'] = "⬅️ Orqaga";
$LANG["uz"]['start'] = "<b>Salom $name botimizga xush kelibsiz!
 📁 Ushbu bot orqali siz Chiroyli nik tayyorlashingiz mumkin</b>";
$LANG["uz"]['yuklaysiz'] = "Siz nima yuklamoqchisiz🔽";
$LANG["uz"]['yukla'] = "Yuklanmoqda...⌛";
$LANG["uz"]['yuklandi'] = "✅ <b> Video tayyor!</b>

$bot";
$LANG["uz"]['azo'] = "❗ Siz hali kanalimizga a'zo bo'lmadingiz.";



//Russkiy
$LANG["ru"]['name_language'] = "🇷🇺Русский язык";
$LANG["ru"]['Choose_language'] = "Выберите язык бота.";
$LANG["ru"]['changed_language'] = "🇷🇺Русский язык сохранился

📁 С помощью этого бота можно сделать Красивого Ника";
$LANG["ru"]['menu1'] = "Без знаков видео 🎞";
$LANG["ru"]['menu2'] = "С Знаков видео📇";
$LANG["ru"]['menu3'] = "Музыка🎶";
$LANG["ru"]['Back'] = "⬅️ Назад";
$LANG["ru"]['start'] = "<b> Привет, $name ! Добро пожаловать в наш бот!

📁 С помощью этого бота можно сделать Красивого Ника</b>";

$LANG["ru"]['yuklaysiz'] = "Что вы хотите загрузить 🔽";
$LANG["ru"]['yukla'] = "Загрузка...⌛";
$LANG["ru"]['yuklandi'] = "✅ <b> Видео готово!</b>

$bot";
$LANG["ru"]['azo'] = "❗ Вы еще не являетесь участником нашего канала.";

//English
$LANG["en"]['name_language'] = "English 🇺🇸";
$LANG["en"]['Choose_language'] = "Choose the bot language.";
$LANG["en"]['changed_language'] = "English 🇺🇸 Changes saved!

📁 With this bot you can make a Beautiful Nick";
$LANG["en"]['menu1'] = "No Watemark 🎞";
$LANG["en"]['menu2'] = "Watemark 📇";
$LANG["en"]['menu3'] = "Music🎶";
$LANG["en"]['Back'] = "⬅️ Cancel";
$LANG["en"]['start'] = "<b>Hello $name! Welcome to our bot!
📁 With this bot you can make a Beautiful Nick</b>";
$LANG["en"]['yuklaysiz'] = "What do you want to upload🔽";
$LANG["en"]['yukla'] = "Loading...⌛";
$LANG["en"]['yuklandi'] = "✅ <b> The video is ready!</b>

$bot";
$LANG["en"]['azo'] = "❗ You are not yet a member of our channel.";