<?php
# » Header « #
header('Content-Type: application/json;charset=utf-8');
include_once('jdf.php');
# » Get « #
$file = html_entity_decode(file_get_contents('https://time.ir'));
preg_match_all('#<span id="(.*?)" class="show date">(.*?)</span>#',$file,$res);
# » Print « #
echo json_encode(
    array_merge([
        'ok'=> true,
        'results'=> [
            'time' => tr_num(jdate('H:i:s')),
            'Today' => $res[2][0],
            'Lunar' => $res[2][2],
            'ad' => $res[2][1],
            'Elapsed' => tr_num(jdate('z')),
            'ElapsedPercentage' => tr_num(jdate('K')),
            'remaining' => (365-tr_num(jdate('z'))),
            'remainingPercentage' => tr_num(jdate('k'))
        ],
    ]
    ), 448
);