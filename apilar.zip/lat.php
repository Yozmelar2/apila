<?php
header('Content-Type: application/json; charset=utf-8');
$son = $_GET['son'];
$sayt =file_get_contents("https://latifa.uz/uz_latn/show/$son");
$ism =explode('<div data-id="'.$son.'">', $sayt);
$ism =explode('</div>',$ism[1]);
$ism = $ism[0];
$ism= str_replace(["\n"],[""],$ism);
$ism= str_replace(["<br />"],["\n"],$ism);
$ism= str_replace(["&mdash;"],["— "],$ism);
$ism= str_replace(["&laquo;"],["•"],$ism);
$ism= str_replace(["&raquo;"],["•"],$ism);
$ism = trim($ism);

$a = array(
'ism'=>"$ism");
echo json_encode($a);