<?php
    session_start();
    $code = $_GET["text"];
    if($code == null)
    {
        $code = rand(11111,99999);
    }
    $captcha_vms = substr($code, 0, 6);
    $_SESSION["captcha"] = $captcha_vms;
    $target = imagecreatetruecolor(80,35);
    $captcha_background = imagecolorallocate($target, 187, 187, 20);
    imagefill($target,0,0,$captcha_background);
    $captcha_fore_color = imagecolorallocate($target, 255, 255, 255);
    imagestring($target, 8, 18, 9, $captcha_vms,$captcha_fore_color);
    header("Content-type: image/png");
    imagejpeg($target);
    
?>
